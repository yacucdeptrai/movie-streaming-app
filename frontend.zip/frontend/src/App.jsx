"use client"

import { useState } from "react"
import MovieList from "./components/MovieList"
import MovieDetail from "./components/MovieDetail"
import "./index.css"

function App() {
  const [selectedMovie, setSelectedMovie] = useState(null)

  const handleSelectMovie = (movie) => {
    setSelectedMovie(movie)
  }

  const handleBackToList = () => {
    setSelectedMovie(null)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black text-white">
      {/* Header */}
      <header className="bg-black/50 backdrop-blur-md border-b border-gray-700 sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="text-2xl font-bold bg-gradient-to-r from-red-500 to-pink-500 bg-clip-text text-transparent">
                🎬 MovieStream
              </div>
              {selectedMovie && (
                <button
                  onClick={handleBackToList}
                  className="flex items-center space-x-2 px-4 py-2 bg-gray-700/50 hover:bg-gray-600/50 rounded-lg transition-all duration-200"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                  </svg>
                  <span>Quay lại</span>
                </button>
              )}
            </div>
            <nav className="hidden md:flex items-center space-x-6">
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                Trang chủ
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                Phim mới
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                Thể loại
              </a>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {selectedMovie ? (
          <MovieDetail movie={selectedMovie} onBack={handleBackToList} />
        ) : (
          <MovieList onSelectMovie={handleSelectMovie} />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-black/30 border-t border-gray-700 mt-16">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center text-gray-400">
            <p>&copy; 2024 MovieStream. Tất cả quyền được bảo lưu.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App
