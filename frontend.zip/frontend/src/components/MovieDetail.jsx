"use client"

import { useState } from "react"
import axios from "axios"
import VideoPlayer from "./VideoPlayer"

function MovieDetail({ movie, onBack }) {
  const [resolutions, setResolutions] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [isFullScreen, setIsFullScreen] = useState(false)

  const handlePlay = async () => {
    setLoading(true)
    setError(null)
    try {
      const response = await axios.get(`/api/stream/${movie.movie_id}`)

      const data = response.data
      if (data.resolutions && data.resolutions.length > 0) {
        setResolutions(data.resolutions)
        setIsFullScreen(true)
      } else {
        setError("Không có video khả dụng cho phim này.")
      }
    } catch (err) {
      console.error("Streaming API Error:", err)
      if (err.response?.status === 404) {
        setError("Video chưa được xử lý hoặc không tồn tại.")
      } else {
        setError("Không thể tải video. Vui lòng thử lại sau.")
      }
    } finally {
      setLoading(false)
    }
  }

  const handleExitFullScreen = () => {
    setIsFullScreen(false)
    setResolutions(null)
  }

  if (resolutions && isFullScreen) {
    return <VideoPlayer resolutions={resolutions} onBack={handleExitFullScreen} movieTitle={movie.title} />
  }

  return (
    <div className="max-w-7xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Movie Poster & Play Button */}
        <div className="lg:col-span-1">
          <div className="sticky top-24">
            <div className="relative group">
              <div className="aspect-[2/3] rounded-2xl overflow-hidden shadow-2xl">
                <img
                  src={movie.thumbnail || `https://picsum.photos/400/600?random=${movie.movie_id}`}
                  alt={movie.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
              </div>

              {/* Play Button */}
              <div className="absolute inset-0 flex items-center justify-center">
                <button
                  onClick={handlePlay}
                  disabled={loading}
                  className={`group relative overflow-hidden bg-red-500 hover:bg-red-600 text-white rounded-full p-6 transform transition-all duration-300 hover:scale-110 shadow-2xl ${
                    loading ? "animate-pulse" : ""
                  }`}
                >
                  {loading ? (
                    <div className="w-8 h-8 border-3 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M8 5v14l11-7z" />
                    </svg>
                  )}
                  <div className="absolute inset-0 bg-white/20 transform scale-0 group-hover:scale-100 transition-transform duration-300 rounded-full" />
                </button>
              </div>

              {/* Quality Badges */}
              <div className="absolute top-4 left-4 space-y-2">
                <span className="bg-red-500 text-white text-sm font-bold px-3 py-1 rounded-full">HD</span>
                <span className="bg-green-500 text-white text-sm font-bold px-3 py-1 rounded-full">Miễn phí</span>
              </div>
            </div>

            {error && (
              <div className="mt-4 p-4 bg-red-500/10 border border-red-500/20 rounded-xl">
                <p className="text-red-400 text-center">{error}</p>
              </div>
            )}
          </div>
        </div>

        {/* Movie Information */}
        <div className="lg:col-span-2 space-y-8">
          {/* Title & Basic Info */}
          <div className="space-y-4">
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
              {movie.title}
            </h1>

            <div className="flex flex-wrap items-center gap-4 text-gray-300">
              {movie.release_year && (
                <div className="flex items-center space-x-2">
                  <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                    />
                  </svg>
                  <span>{movie.release_year}</span>
                </div>
              )}

              {movie.genre && (
                <div className="flex items-center space-x-2">
                  <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"
                    />
                  </svg>
                  <span className="bg-gray-700 px-3 py-1 rounded-full text-sm">{movie.genre}</span>
                </div>
              )}

              <div className="flex items-center space-x-2">
                <svg className="w-5 h-5 text-yellow-400" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                </svg>
                <span className="text-yellow-400 font-semibold">8.5</span>
                <span className="text-gray-400">(1,234 đánh giá)</span>
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="space-y-4">
            <h2 className="text-2xl font-semibold text-white">Nội dung phim</h2>
            <p className="text-gray-300 text-lg leading-relaxed">
              {movie.description || "Chưa có mô tả cho bộ phim này."}
            </p>
          </div>

          {/* Additional Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="text-xl font-semibold text-white">Thông tin chi tiết</h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-400">Thể loại:</span>
                  <span className="text-white">{movie.genre || "Chưa cập nhật"}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Năm sản xuất:</span>
                  <span className="text-white">{movie.release_year || "Chưa cập nhật"}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Chất lượng:</span>
                  <span className="text-green-400">HD</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Ngôn ngữ:</span>
                  <span className="text-white">Tiếng Việt</span>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-semibold text-white">Tính năng</h3>
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <svg className="w-5 h-5 text-green-400" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <span className="text-gray-300">Phát trực tuyến HD</span>
                </div>
                <div className="flex items-center space-x-3">
                  <svg className="w-5 h-5 text-green-400" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <span className="text-gray-300">Nhiều chất lượng</span>
                </div>
                <div className="flex items-center space-x-3">
                  <svg className="w-5 h-5 text-green-400" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <span className="text-gray-300">Tương thích mọi thiết bị</span>
                </div>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap gap-4 pt-6">
            <button
              onClick={handlePlay}
              disabled={loading}
              className="flex items-center space-x-3 bg-red-500 hover:bg-red-600 text-white px-8 py-4 rounded-xl font-semibold transition-all duration-200 transform hover:scale-105 shadow-lg"
            >
              <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                <path d="M8 5v14l11-7z" />
              </svg>
              <span>{loading ? "Đang tải..." : "Xem ngay"}</span>
            </button>

            <button className="flex items-center space-x-3 bg-gray-700 hover:bg-gray-600 text-white px-8 py-4 rounded-xl font-semibold transition-all duration-200">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
                />
              </svg>
              <span>Yêu thích</span>
            </button>

            <button className="flex items-center space-x-3 bg-gray-700 hover:bg-gray-600 text-white px-8 py-4 rounded-xl font-semibold transition-all duration-200">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.367 2.684 3 3 0 00-5.367-2.684z"
                />
              </svg>
              <span>Chia sẻ</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default MovieDetail
