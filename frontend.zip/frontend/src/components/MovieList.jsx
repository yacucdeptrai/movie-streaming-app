"use client"

import { useState, useEffect } from "react"
import axios from "axios"

function MovieList({ onSelectMovie }) {
  const [movies, setMovies] = useState([])
  const [query, setQuery] = useState("")
  const [page, setPage] = useState(1)
  const [limit] = useState(12)
  const [pagination, setPagination] = useState({ current_page: 1, total_pages: 1 })
  const [loading, setLoading] = useState(false)

  const fetchMovies = async () => {
    setLoading(true)
    try {
      const response = await axios.get("/api/search", {
        params: { query: query || undefined, page, limit },
      })

      const moviesData = response.data?.movies || []
      const paginationData = response.data?.pagination || { current_page: 1, total_pages: 1 }

      setMovies(Array.isArray(moviesData) ? moviesData : [])
      setPagination(paginationData)
    } catch (error) {
      console.error("Error fetching movies:", error)
      setMovies([])
      setPagination({ current_page: 1, total_pages: 1 })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchMovies()
  }, [query, page])

  const handleSearch = (e) => {
    setQuery(e.target.value)
    setPage(1)
  }

  const handlePageChange = (newPage) => {
    if (newPage >= 1 && newPage <= pagination.total_pages) {
      setPage(newPage)
    }
  }

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-red-500 via-pink-500 to-purple-500 bg-clip-text text-transparent">
          Khám Phá Thế Giới Điện Ảnh
        </h1>
        <p className="text-xl text-gray-300 max-w-2xl mx-auto">
          Thưởng thức hàng nghìn bộ phim chất lượng cao với trải nghiệm xem tuyệt vời
        </p>
      </div>

      {/* Search Section */}
      <div className="max-w-2xl mx-auto">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
            <svg className="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
              />
            </svg>
          </div>
          <input
            type="text"
            placeholder="Tìm kiếm phim yêu thích của bạn..."
            value={query}
            onChange={handleSearch}
            className="w-full pl-12 pr-4 py-4 bg-gray-800/50 backdrop-blur-sm border border-gray-600 rounded-2xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all duration-200"
          />
        </div>
      </div>

      {/* Stats */}
      {!loading && movies && movies.length > 0 && (
        <div className="flex justify-center">
          <div className="bg-gray-800/30 backdrop-blur-sm rounded-xl px-6 py-3 border border-gray-700">
            <span className="text-gray-300">
              Tìm thấy <span className="text-red-400 font-semibold">{pagination.total_movies || movies.length}</span>{" "}
              phim
            </span>
          </div>
        </div>
      )}

      {/* Movies Grid */}
      <div className="min-h-[400px]">
        {loading ? (
          <div className="flex flex-col items-center justify-center h-64 space-y-4">
            <div className="relative">
              <div className="w-16 h-16 border-4 border-gray-600 border-t-red-500 rounded-full animate-spin"></div>
              <div className="absolute inset-0 w-16 h-16 border-4 border-transparent border-t-pink-500 rounded-full animate-spin animation-delay-150"></div>
            </div>
            <p className="text-gray-400 text-lg">Đang tải phim...</p>
          </div>
        ) : !movies || movies.length === 0 ? (
          <div className="text-center py-16">
            <div className="text-6xl mb-4">🎬</div>
            <h3 className="text-2xl font-semibold mb-2">Không tìm thấy phim nào</h3>
            <p className="text-gray-400">Thử tìm kiếm với từ khóa khác hoặc xem tất cả phim</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-6">
            {movies.map((movie, index) => (
              <div
                key={movie.movie_id}
                className="group cursor-pointer transform transition-all duration-300 hover:scale-105"
                onClick={() => onSelectMovie(movie)}
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="relative overflow-hidden rounded-xl bg-gray-800 shadow-lg group-hover:shadow-2xl transition-all duration-300">
                  {/* Movie Poster */}
                  <div className="aspect-[2/3] relative overflow-hidden">
                    <img
                      src={movie.thumbnail || `https://picsum.photos/300/450?random=${movie.movie_id}`}
                      alt={movie.title}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                    {/* Play Button Overlay */}
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300">
                      <div className="bg-red-500 rounded-full p-4 transform scale-75 group-hover:scale-100 transition-transform duration-300">
                        <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M8 5v14l11-7z" />
                        </svg>
                      </div>
                    </div>

                    {/* Quality Badge */}
                    <div className="absolute top-3 left-3">
                      <span className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded">HD</span>
                    </div>

                    {/* Year Badge */}
                    {movie.release_year && (
                      <div className="absolute top-3 right-3">
                        <span className="bg-black/70 text-white text-xs px-2 py-1 rounded">{movie.release_year}</span>
                      </div>
                    )}
                  </div>

                  {/* Movie Info */}
                  <div className="p-4 space-y-2">
                    <h3 className="font-semibold text-white line-clamp-2 group-hover:text-red-400 transition-colors duration-200">
                      {movie.title}
                    </h3>
                    <p className="text-sm text-gray-400 line-clamp-2">{movie.description}</p>
                    {movie.genre && (
                      <div className="flex flex-wrap gap-1">
                        <span className="text-xs bg-gray-700 text-gray-300 px-2 py-1 rounded-full">{movie.genre}</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Pagination */}
      {!loading && movies && movies.length > 0 && pagination.total_pages > 1 && (
        <div className="flex justify-center items-center space-x-2">
          <button
            onClick={() => handlePageChange(page - 1)}
            disabled={page === 1}
            className="px-4 py-2 bg-gray-700 hover:bg-gray-600 disabled:bg-gray-800 disabled:text-gray-500 text-white rounded-lg transition-colors duration-200 flex items-center space-x-2"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            <span>Trước</span>
          </button>

          <div className="flex items-center space-x-1">
            {[...Array(Math.min(5, pagination.total_pages))].map((_, i) => {
              const pageNum = i + 1
              return (
                <button
                  key={pageNum}
                  onClick={() => handlePageChange(pageNum)}
                  className={`w-10 h-10 rounded-lg transition-colors duration-200 ${
                    page === pageNum ? "bg-red-500 text-white" : "bg-gray-700 hover:bg-gray-600 text-gray-300"
                  }`}
                >
                  {pageNum}
                </button>
              )
            })}
          </div>

          <button
            onClick={() => handlePageChange(page + 1)}
            disabled={page === pagination.total_pages}
            className="px-4 py-2 bg-gray-700 hover:bg-gray-600 disabled:bg-gray-800 disabled:text-gray-500 text-white rounded-lg transition-colors duration-200 flex items-center space-x-2"
          >
            <span>Sau</span>
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>
      )}
    </div>
  )
}

export default MovieList
